[![MELPA Stable](http://stable.melpa.org/packages/ess-badge.svg)](http://stable.melpa.org/#/ess)
[![MELPA](http://melpa.org/packages/ess-badge.svg)](http://melpa.org/#/ess)

# ESS
Git development branch of Emacs Speaks Statistics: ESS.  
For more info, see our web page at http://ess.r-project.org/

