
##### Filling

### 1a ---------------------------------------------------------------

##' Title
##'
##' @param¶ Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL

##! (fill-paragraph)

##' Title
##'
##' @param¶ Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL


### 1b ---------------------------------------------------------------

##' Title
##'
¶##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL

##! (fill-paragraph)

##' Title
##'
¶##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL


### 2 ----------------------------------------------------------------

##' ¶

##! (global-set-key (kbd "RET") 'newline-and-indent)
##! (substitute-key-definition 'newline-and-indent
##!                            'ess-newline-and-indent
##!                            ess-mode-map global-map)
##! "RET"

##'
##' ¶

##> "RET"

##'
##'
##' ¶

##> (setq ess-roxy-insert-prefix-on-newline nil)
##> "RET"

##'
##'
##'
¶

##! "M-j"

##'
##' ¶
